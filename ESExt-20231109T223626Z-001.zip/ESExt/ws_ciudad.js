//Valores minimos de compra de Recursos
var minimos = {};
minimos.HIERRO = 8;
minimos.RELIQUIAS = 40;
minimos.CRISTAL = 25;
minimos.JOYAS = 25;
minimos.HERRAMIENTAS = 15;
minimos.ARMAS = 20;
minimos.MITHRIL = 20;
minimos.GEMAS = 20;
minimos.PLATA = 15;
minimos.PIEDRA = 6;
minimos.BLOQUES = 10;
minimos.MADERA = 5;
minimos.TABLAS = 10;
minimos.ALIMENTOS = 3;
minimos.AGUA = 3;

//Valores de produccion base de cada edificio
var produccion = {};
produccion.castillo=0;
produccion.muralla=0;
produccion.armeria=0;
produccion.foso=0;
produccion.cuartel=0;
produccion.torremagica=0;
produccion.universidad=0;
produccion.santuario=0;
produccion.templo=0;
produccion.mercado=620;
produccion.mercadonegro=1200;
produccion.minaoro=700;
produccion.minaplata=85*minimos["PLATA"];
produccion.minahierro=130*minimos["HIERRO"];
produccion.minapiedra=175*minimos["PIEDRA"];
produccion.minamithril=63*minimos["MITHRIL"];
produccion.aserradero=238*minimos["MADERA"];
produccion.cultivos=200*minimos["ALIMENTOS"];
produccion.yacimientos=65*minimos.GEMAS;
produccion.pozo=175*minimos.AGUA;
produccion.taller=130*minimos.HIERRO;
produccion.forjahierro=78*minimos.ARMAS;
produccion.forjamithril=30*minimos.RELIQUIAS;
produccion.joyeria=50*minimos["JOYAS"];
produccion.camaracristal=55*minimos["CRISTAL"];
produccion.cantera=105*minimos["BLOQUES"];
produccion.carpinteria=115*minimos["TABLAS"];
produccion.monumentos=1700;
produccion.acueducto=200*minimos["AGUA"];
produccion.almacen=175*minimos["ALIMENTOS"];
produccion.coliseo=0;
produccion.burdeles=0;
produccion.escuela=0;
function terrenos(terreno)
{
  var subtitulo=$(".subtitulo").text();
  var inicioCadena=subtitulo.indexOf(":")+2;
  var finCadeba=subtitulo.indexOf(";")
  var terreno= subtitulo.substring(inicioCadena,finCadeba);
  if(terreno=="Llanura")
  {
    produccion.cultivos=produccion.cultivos*1.8;
    produccion.almacen=produccion.almacen*1.8;
  }
  if(terreno=="Bosque")
  {
    produccion.aserradero=produccion.aserradero*2;
  }
  if(terreno=="Montaña")
  {
    produccion.minahierro=produccion.minahierro*1.4;
    produccion.minamithril=produccion.minamithril*1.3;
  }
  if(terreno=="Rio")
  {
    produccion.pozo=produccion.pozo*2.4;
    produccion.acueducto=produccion.acueducto*2.4;
  }
  if(terreno=="Costa")
  {
    produccion.cultivos=produccion.cultivos*1.6;
    produccion.almacen=produccion.almacen*1.6;
  }
  if(terreno=="Colina")
  {
    produccion.minapiedra=produccion.minapiedra*1.6;
    produccion.yacimientos=produccion.yacimientos*1.3;
  }
}

var masRentable=999999;
var masRentableI=999999;
var edificios = new Array();
var aux;

function ciudad()
{
  GLOBAL.showOpcionesDisponibles();

  chrome.storage.sync.get({
    construcciones: true
  }, function(items) {

    if(items.construcciones)
      ciudad_process();
  });
}

function ciudad_process()
{
  if($(".c .nome").length == 0)
    return;

  UTIL.injectCode(function(){
    $("body").append("<input id='valoresEdificio' type=hidden value=" + JSON.stringify(__edificio) + " />");
    $("body").append("<input id='recursosActuales' type=hidden value=" + JSON.stringify(imp) + " />");
  });

  var costosIniciales = JSON.parse($("#valoresEdificio").val());
  var recursosActuales = JSON.parse($("#recursosActuales").val());
  var recursosUsados = JSON.parse($("#recursosActuales").val());
  var edificiosConstruidos = new Array();

  ciudad_cleanUsados(recursosUsados);

  UTIL.injectCode(function(){
    $("#valoresEdificio").remove();
    $("#recursosActuales").remove();
  });

  
  $(".c .nome").each(function(index, obj){
    var nombre = $(obj).text().trim().replace(" ","").replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u").toLowerCase();
    edificios.push(nombre);
    edificiosConstruidos.push(-1)
  });
  var costosTotales = new Array();

  for(var i = 0; i < edificios.length; i++)
  {
    var oroInicial = costosIniciales[i][0];
    var materialInicial = costosIniciales[i][1];
    var nombreRecurso = costosIniciales[i][2];
    var renta = renta_edif_base(oroInicial,materialInicial,nombreRecurso.toUpperCase(),edificios[i]);
    var costo = new Array();
    for (var j=1; j <=10; j++)
    {
    costo.push({ oro: ciudad_calcular(oroInicial, j), material: ciudad_calcular(materialInicial, j), recurso: nombreRecurso, rentabilidad: renta*j});
    }
    costosTotales.push(costo);
  }
  ciudad_estrellas(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos);
  $(".estrella").each(function(index, obj){
     $(obj).mouseenter(function(){ ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos); });
     $(obj).click(function(){ ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos); });
  });

  $(".c.c_r").each(function(index, obj){
      // $(obj).mouseout(function(){ ciudad_estrellas(costosTotales, recursosActuales, recursosUsados); });
      $(obj).hover(function(){ ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos); });
  });

  $(".elim").each(function(index, obj){
     $(obj).click(function(){ ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos); });
    //  $(obj).hover(function(){ ciudad_recalcular(costosTotales, recursosActuales, recursosUsados); });
  });

  $(".edificios img:not(.estrella):not(.elim):not(._ayuda):not(.ayuda)").each(function(index, obj){
      var id = obj.id;
      var estrella = parseInt(id.replace("edificio_estrella_", ""));
      var edificio = Math.floor(estrella / 10);
      var nroEdificio = estrella % 10;

      if(nroEdificio > edificiosConstruidos[edificio])
        edificiosConstruidos[edificio] = nroEdificio;
  });

  ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos);
}

function ciudad_cleanUsados(recursosUsados)
{
  for(var key in recursosUsados)
    recursosUsados[key] = 0;
}

function ciudad_recalcular(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos)
{
  ciudad_cleanUsados(recursosUsados);

  if($("#panel").html() == "")
  {
    ciudad_estrellas(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos);
    return;
  }

  var costeOro = parseInt($("#panel #costeoro").html().trim());
  recursosUsados["ORO"] = costeOro;

  $("#panel [id*='coste']:not(#costeoro)").each(function(index, obj){
    var nombre = obj.id.replace("coste", "");
    var costo = parseInt($(obj).html().trim());
    recursosUsados[nombre.toUpperCase()] = costo;
  });

  ciudad_estrellas(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos);
}

function ciudad_estrellas(costosTotales, recursosActuales, recursosUsados, edificiosConstruidos)
{
  $(".estrella").each(function(index, obj){

    if(obj.src == "https://images.empire-strike.com/v2/interfaz/estrella-amarilla.png" ||
       obj.src == "https://images.empire-strike.com/v2/interfaz/estrella-roja.png")
      return;

    var id = obj.id;
    var estrella = parseInt(id.replace("edificio_estrella_",""));
    var edificio = Math.floor(estrella/10);
    var nroEdificio = estrella % 10;

    var costoOro = costosTotales[edificio][nroEdificio].oro;
    var costoMat = costosTotales[edificio][nroEdificio].material;
    var recurso = costosTotales[edificio][nroEdificio].recurso.toUpperCase();
    var renta = costosTotales[edificio][nroEdificio].rentabilidad;
    
    var edificioContruid = edificiosConstruidos[edificio];
    var construidoOro = edificioContruid == -1 ? 0 : costosTotales[edificio][edificioContruid].oro;
    var construidoMat = edificioContruid == -1 ? 0 : costosTotales[edificio][edificioContruid].material;

    if((recursosActuales["ORO"] - recursosUsados["ORO"]) >= (costoOro - construidoOro) && (recursosActuales[recurso] - recursosUsados[recurso]) >= (costoMat - construidoMat))
      {obj.src = chrome.extension.getURL('base/estrella-verde.png');
        //var ren=renta_edif_base (costoOro,costoMat,recurso,edificios[edificio]);
        //$(".tituloimperio").append(renta+edificios[edificio]+produccion[edificios[edificio]]+recurso+"<br>");

        if(renta<=masRentable)
          {
            masRentable=renta;
            obj.src = chrome.extension.getURL('base/estrella-azul.png');
          }
      } 
    else
    {
      obj.src = "https://images.empire-strike.com/v2/interfaz/estrella-vacia.png";
      if(renta<=masRentableI&&renta<masRentable)
      {
        masRentableI=renta;
        obj.src = chrome.extension.getURL('base/estrella-blanca.png');
      }
    }
      
  })
}

function ciudad_calcular(inicio, estrella)
{
  var result = 0;
  for(var i = 0; i <= estrella; i++)
    result += inicio * i;

  return result;
}

function renta_edif_base (costoOro,costoMat,recurso,nombre)
{ var politic=1;
  var region=1;
  var renta=99999;
  if(produccion[nombre]>0)
  {
  var costo=costoOro+costoMat*minimos[recurso];
  renta=costo/produccion[nombre];
  }
  return renta;
}

function renta_edif_hoy ()
{
  return 0;
}