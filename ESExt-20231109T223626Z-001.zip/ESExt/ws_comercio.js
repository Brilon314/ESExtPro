function comercio()
{
	var maximos = {};
	maximos.Hierro = 10;
	maximos.Reliquias = 60;
	maximos.Cristal = 37;
	maximos.Joyas = 37;
	maximos.Herramientas = 21;
	maximos.Armas = 28;
	maximos.Mithril = 28;
	maximos.Gemas = 28;
	maximos.Plata = 21;
	maximos.Piedra = 8;
	maximos.Bloques = 12;
	maximos.Madera = 6;
	maximos.Tablas = 12;
	maximos.Alimentos = 3;
	maximos.Agua = 3;

	var minimos = {};
	minimos.Hierro = 8;
	minimos.Reliquias = 40;
	minimos.Cristal = 25;
	minimos.Joyas = 25;
	minimos.Herramientas = 15;
	minimos.Armas = 20;
	minimos.Mithril = 20;
	minimos.Gemas = 20;
	minimos.Plata = 15;
	minimos.Piedra = 6;
	minimos.Bloques = 10;
	minimos.Madera = 5;
	minimos.Tablas = 10;
	minimos.Alimentos = 3;
	minimos.Agua = 3;

	var valoresVenta = {};
	$(".lista1 tr").each(function(index, obj) {
		if(index == 0)
			return;

	  if(obj.children.length < 3)
			return;

		var nombre = $(obj.children[0]).text().trim();
		var venta = parseInt($(obj.children[3]).text().trim());
		var compra = parseInt($(obj.children[2]).text().trim());

		valoresVenta[nombre.toUpperCase()] = venta;

		var difCompra = compra - minimos[nombre];
		if(difCompra == 0)
			$(obj.children[2]).append("<img src='https://images.empire-strike.com/v2/iconos/icon_correcto.png' alt='Precio óptimo' title='Precio óptimo'>");
		else
			$(obj.children[2]).append("<span style='font-size:11px'><b style='color:#990000'>+" + difCompra + "</b></span>");

		var difVenta = venta - maximos[nombre];
		if(difVenta == 0)
			$(obj.children[3]).append("<img src='https://images.empire-strike.com/v2/iconos/icon_correcto.png' alt='Precio óptimo' title='Precio óptimo'>");
		else
			$(obj.children[3]).append("<span style='font-size:11px'><b style='color:#990000'>" + difVenta + "</b></span>");
	});

	var selectRecurso = "";
	var selectVenta = 0;
	$("[name=recurso] option").each(function(index, obj){
		var text = $(obj).text();
		
		var recurso = "";
		var cantidad = "";
		for(var rec in valoresVenta)
		   if(text.indexOf(rec) != -1)
		   {
				recurso = rec;
				cantidad = text.replace(rec, "");
				break;
			}
		
		cantidad = parseInt(cantidad.trim().replace(".", ""));

		if(valoresVenta[recurso.toUpperCase()] * cantidad > selectVenta)
		{
			selectRecurso = recurso;
			selectVenta = valoresVenta[recurso] * cantidad;
		}

	});

	$(".cont_mejora").append("<span style='color: #990000; font-weight: bold'>Canje óptimo de rubies basado en el comercio actual: " + selectRecurso + " - " + selectVenta + " <span class='sprite-recurso oro absmiddle' title='Oro'></span></span>")

}
